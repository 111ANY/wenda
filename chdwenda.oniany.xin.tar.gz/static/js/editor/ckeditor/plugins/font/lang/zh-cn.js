﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'zh-cn', {
	fontSize: {
		label: '大小',
		voiceLabel: '文字大小',
		panelTitle: '大小'
	},
	label: '字体',
	panelTitle: '字体',
	voiceLabel: '字体'
} );
